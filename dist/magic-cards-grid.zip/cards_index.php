<?php

/**
 * The template for the magic-cards-grid section of the page
 * Search and sort functions need to be added
 */

?>

<!--<div class="d-flex" id="magic_search">-->
<!--    <input id="magic_searchterm" type="text" /> <button id="search">search</button>-->
<!--</div>-->

<div class="container d-flex flex-wrap" id="magic_cards_grid">

</div>
<div id="loadCards" data-pagenum="" class="container d-flex flex-wrap loading_txt">
    <img src="<?php plugins_url( '/img/Spinner-1s-200px.gif', __FILE__ )?>" />
</div>